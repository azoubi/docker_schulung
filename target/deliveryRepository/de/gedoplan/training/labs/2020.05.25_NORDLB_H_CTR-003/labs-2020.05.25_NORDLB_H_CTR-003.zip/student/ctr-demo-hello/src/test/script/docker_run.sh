#!/bin/sh
NAMESPACE=gedoplan-seminar
REPOSITORY=ctr-demo-hello

docker run --rm --name $REPOSITORY $NAMESPACE/$REPOSITORY